const Fooddata = [
    {
        id: 1,
        rname: "Mughalai Biryani",
        imgdata: "https://img.freepik.com/premium-photo/dum-handi-chicken-biryani-is-prepared-earthen-clay-pot-called-haandi-popular-indian-non-vegetarian-food_466689-52336.jpg?size=626&ext=jpg&ga=GA1.1.1427699111.1680582715&semt=ais",
        address: "North Indian, Biryani, Mughlai",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: " 1075 + order placed from here recently",
        price: "₹299 for one",
        rating: "3.8",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 2,
        rname: "South Adda",
        imgdata: "https://img.freepik.com/premium-photo/masala-dosa-is-south-indian-meal-served-with-sambhar-coconut-chutney-selective-focus_466689-22925.jpg?size=626&ext=jpg&ga=GA1.1.1427699111.1680582715&semt=sph",
        address: "Idli, Dosas, Vadas",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: " 2100 + order placed from here recently",
        price: "₹149 for one",
        rating: "4.1",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 3,
        rname: "Pizza Van",
        imgdata: "https://img.freepik.com/free-photo/top-view-pepperoni-pizza-sliced-into-six-slices_141793-2157.jpg?size=626&ext=jpg&ga=GA1.1.1427699111.1680582715&semt=sph",
        address: "Pizza, Fast Food, Pasta",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: " 650 + order placed from here recently",
        price: "₹109 for one",
        rating: "4.2",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 4,
        rname: "Momo Point",
        imgdata: "https://b.zmtcdn.com/data/pictures/chains/1/113401/59f29399060caefcc575d59dc9402ce8_o2_featured_v2.jpg",
        address: "Momos, Noodles",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: " 300 + order placed from here recently",
        price: "₹89 for one",
        rating: "3.8",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 5,
        rname: "Kaesar Da Dhaba",
        imgdata: "https://img.freepik.com/free-photo/high-angle-pakistani-dish-arrangement_23-2148825102.jpg?size=626&ext=jpg&ga=GA1.1.1427699111.1680582715&semt=ais",
        address: "North Indian Cuisine",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: "1050 + order placed from here recently",
        price: "₹199 for one",
        rating: "4.0",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 6,
        rname: "Chaap Nation",
        imgdata: "https://img.freepik.com/free-photo/chicken-skewers-with-slices-apples-chili-top-view_2829-19996.jpg?size=626&ext=jpg&ga=GA1.1.1427699111.1680582715&semt=ais",
        address: "Wraps Chaap, Chines",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: " 1100 + order placed from here recently",
        price: "₹121 for one",
        rating: "3.8",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 7,
        rname: "Jassa Sweets",
        imgdata: "https://b.zmtcdn.com/data/pictures/chains/5/110155/811c01a5430d50d3260f77917da99e12_o2_featured_v2.jpg",
        address: "North Indian Sweets, Fast Food",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: "500 + order placed from here recently",
        price: "₹59 for one",
        rating: "3.8",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 8,
        rname: "Winnie's",
        imgdata: "https://img.freepik.com/free-photo/two-milk-shakes-table_140725-9292.jpg?size=626&ext=jpg&ga=GA1.2.1427699111.1680582715&semt=sph",
        address: "Tea, Coffee, Shakes, Beverages",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: "500 + order placed from here recently",
        price: "₹99 for one",
        rating: "3.2",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    {
        id: 9,
        rname: "Burger Point",
        imgdata: "https://img.freepik.com/free-vector/burger-fast-food-concept-hand-drawn-sketch-vector-illustration_91128-1533.jpg?w=2000",
        address: "Burger, Sandwich, Fast Food",
        delimg: "https://b.zmtcdn.com/data/o2_assets/0b07ef18234c6fdf9365ad1c274ae0631612687510.png?output-format=webp",
        somedata: "2525 + order placed from here recently",
        price: "₹72 for one",
        rating: "3.8",
        arrimg: "https://b.zmtcdn.com/data/o2_assets/4bf016f32f05d26242cea342f30d47a31595763089.png?output-format=webp"
    },
    
];

export default Fooddata;